sap.ui.define([
	"sap/uxap/BlockBase",
	"sap/ui/core/mvc/Controller"
], function (BlockBase,Controller) {
	"use strict";
	return BlockBase.extend("lrftracker.view.blocks.MatInfoBlock", {
		
				onInit: function(oEvent) {
		},
		
	});
});
